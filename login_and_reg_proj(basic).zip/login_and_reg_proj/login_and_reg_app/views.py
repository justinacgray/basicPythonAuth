from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
import bcrypt

# Create your views here.


def index(request):
    return render(request, "index.html")


def register(request):
    if request.POST:
        # validatiion check
        errors = User.objects.reg_valid(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")

        hash_pw = bcrypt.hashpw(
            request.POST['password'].encode(), bcrypt.gensalt()).decode()
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        email = request.POST["email"]

        new_user = User.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=hash_pw,
        )
        request.session['user_id'] = new_user.id
        # we use redirect and not render so we don't submit multiple requests with the same form
        return redirect("/success")
    return redirect("/")


def login(request):
    # validation check
    context = {}
    if request.POST:
        errors = User.objects.login_valid(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")

        user = User.objects.get(email=request.POST['email'])
        if bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
            request.session['user_id'] = user.id
        return redirect("/success")
    else:
        context["message"] = "Sorry, these credentials are invalid. Please, try again"
    return render(request, '/', context)


def logout(request):
    request.session.flush()
    return redirect("/")


def success(request):
    if 'user_id' not in request.session:
        return redirect('/')
    one_user = User.objects.filter(id=request.session['user_id'])
    context = {
        'user': one_user[0]
    }

    return render(request, 'success.html', context)
