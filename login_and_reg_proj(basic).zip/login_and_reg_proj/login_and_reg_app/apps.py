from django.apps import AppConfig


class LoginAndRegAppConfig(AppConfig):
    name = 'login_and_reg_app'
