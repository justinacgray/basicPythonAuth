from django.db import models
from django.db.models.fields import related
from django.db.models.fields.related import ManyToManyField


import re 
#global variable and access EMAIL_REGEX from anywhere in this file
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

# Create your models here.
class UserManager(models.Manager):
    def reg_valid(self,postData):
        errors = {}
        #length of the first name
        if len(postData["first_name"]) < 2:
            errors["first_name"] = "First Name must be at least 2 characters"
        #length of the last name
        if len(postData["last_name"]) < 2:
            errors["last_name"] = "Last Name ust be at least 2 characters"
        #email matches format
        if not EMAIL_REGEX.match(postData['email']):    # test whether a field matches the pattern            
            errors['email'] = ("Invalid email address!")
        #email already in use?
        current_users = User.objects.filter(email=postData['email'])
        if len(current_users) > 0:
            errors["duplicate"] = "That email is already in use"
        #password was entered(less than 8)
        if len(postData['password']) < 8:
            errors["password"] = "Password must be minimum 8 characters"
        if postData["password"] != postData["password_confirmation"]:
            errors["password_match"] = "Passwords do not match"
        return errors
    
    def login_valid(self,postData):
        errors = {}
        authenticate_login = User.objects.filter(email=postData['email'])
        if len(postData['email']) == 0:
            errors['email'] = "Email must be entered"
        #password has been entered
        if len(postData["password"]) == 0:
            errors["password"] = "Password must be entered"
        #if email and password match the DB
        return errors


class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager() 